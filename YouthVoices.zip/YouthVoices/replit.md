# YoungBlood Blog Platform

## Overview

YoungBlood is a full-stack blogging platform designed to amplify youth voices through authentic storytelling. The application enables users to create, publish, and interact with articles across various categories, fostering a community of young writers and readers.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized builds
- **UI Framework**: Shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom design tokens and dark theme
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Forms**: React Hook Form with Zod validation

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ESM modules
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon serverless PostgreSQL
- **Authentication**: Replit Auth with OpenID Connect
- **Session Management**: Express sessions with PostgreSQL store
- **File Uploads**: Multer for image handling

### Key Components

#### Authentication System
- **Provider**: Replit Auth using OpenID Connect
- **Session Storage**: PostgreSQL-backed sessions with connect-pg-simple
- **User Management**: Automatic user creation/update on authentication
- **Security**: HTTP-only cookies with secure flags

#### Content Management
- **Rich Text Editor**: Custom editor with markdown-style formatting
- **Article System**: Full CRUD operations with draft/publish states
- **Categories**: Predefined categories for content organization
- **Media Handling**: Image upload and serving with size limits

#### Social Features
- **Comments**: Nested commenting system with author attribution
- **Likes**: Article engagement tracking
- **User Profiles**: Author information and article history

#### Database Schema
- **Users**: Profile information, authentication data
- **Articles**: Content, metadata, publishing state
- **Comments**: Hierarchical discussions
- **Likes**: Engagement tracking
- **Sessions**: Authentication session storage

## Data Flow

1. **Authentication Flow**:
   - User initiates login via Replit Auth
   - OpenID Connect verification
   - User profile creation/update
   - Session establishment

2. **Content Creation Flow**:
   - Rich text editor for content creation
   - Form validation with Zod schemas
   - Image upload and processing
   - Draft/publish state management

3. **Content Consumption Flow**:
   - Article listing with pagination
   - Individual article viewing
   - Comment and like interactions
   - User profile browsing

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: Database connectivity
- **drizzle-orm**: Type-safe database operations
- **@tanstack/react-query**: Server state management
- **@radix-ui/***: Accessible UI components
- **react-hook-form**: Form handling
- **zod**: Schema validation
- **tailwindcss**: Styling framework

### Development Dependencies
- **drizzle-kit**: Database migrations
- **tsx**: TypeScript execution
- **vite**: Build tooling
- **@replit/vite-plugin-runtime-error-modal**: Development error handling

### Authentication Dependencies
- **openid-client**: OpenID Connect implementation
- **passport**: Authentication middleware
- **express-session**: Session management
- **connect-pg-simple**: PostgreSQL session store

## Deployment Strategy

### Build Process
1. **Frontend**: Vite builds React app to `dist/public`
2. **Backend**: esbuild bundles server code to `dist/index.js`
3. **Database**: Drizzle migrations applied via `db:push`

### Environment Configuration
- **DATABASE_URL**: PostgreSQL connection string
- **SESSION_SECRET**: Session encryption key
- **REPLIT_DOMAINS**: Authentication domain configuration
- **ISSUER_URL**: OpenID Connect issuer endpoint

### Production Considerations
- **Static Assets**: Served from `dist/public`
- **File Uploads**: Stored in local `uploads` directory
- **Session Storage**: PostgreSQL-backed for scalability
- **Error Handling**: Comprehensive error boundaries and logging

### Development Workflow
- **Hot Reload**: Vite dev server with HMR
- **TypeScript**: Strict type checking across the stack
- **Database**: Push-based schema updates for rapid iteration
- **Authentication**: Replit Auth integration for seamless development

The architecture prioritizes developer experience with hot reloading, type safety, and rapid iteration while maintaining production-ready patterns for authentication, data persistence, and content management.