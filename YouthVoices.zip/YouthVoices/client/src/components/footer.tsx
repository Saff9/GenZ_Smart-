import { Link } from "wouter";
import { Feather, Home, Newspaper, PenTool, Users, Heart, Pen, Laptop, Leaf, HelpCircle, Shield, FileText, Mail, Twitter, Facebook, Instagram, Youtube } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-dark-bg/95 backdrop-blur-sm border-t border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {/* Brand */}
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <Feather className="w-6 h-6 text-primary" />
              <h3 className="text-2xl font-montserrat font-bold text-gradient">
                YOUNGBLOOD
              </h3>
            </div>
            <p className="text-muted-foreground mb-6 leading-relaxed">
              Empowering young voices to share their stories, connect with communities, and drive positive change in the world.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-muted-foreground hover:text-accent transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="#" className="text-muted-foreground hover:text-accent transition-colors">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="text-muted-foreground hover:text-accent transition-colors">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="text-muted-foreground hover:text-accent transition-colors">
                <Youtube className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-xl font-semibold text-accent mb-6 relative">
              Quick Links
              <div className="absolute -bottom-2 left-0 w-12 h-1 bg-primary rounded-full"></div>
            </h3>
            <ul className="space-y-3">
              <li>
                <Link href="/" className="text-muted-foreground hover:text-accent transition-colors hover:pl-2 duration-300 flex items-center">
                  <Home className="w-4 h-4 text-primary mr-3" />
                  Home
                </Link>
              </li>
              <li>
                <a href="#articles" className="text-muted-foreground hover:text-accent transition-colors hover:pl-2 duration-300 flex items-center">
                  <Newspaper className="w-4 h-4 text-primary mr-3" />
                  Browse Articles
                </a>
              </li>
              <li>
                <Link href="/write" className="text-muted-foreground hover:text-accent transition-colors hover:pl-2 duration-300 flex items-center">
                  <PenTool className="w-4 h-4 text-primary mr-3" />
                  Write Article
                </Link>
              </li>
              <li>
                <a href="#community" className="text-muted-foreground hover:text-accent transition-colors hover:pl-2 duration-300 flex items-center">
                  <Users className="w-4 h-4 text-primary mr-3" />
                  Community
                </a>
              </li>
            </ul>
          </div>

          {/* Categories */}
          <div>
            <h3 className="text-xl font-semibold text-accent mb-6 relative">
              Categories
              <div className="absolute -bottom-2 left-0 w-12 h-1 bg-primary rounded-full"></div>
            </h3>
            <ul className="space-y-3">
              <li>
                <a href="#" className="text-muted-foreground hover:text-accent transition-colors hover:pl-2 duration-300 flex items-center">
                  <Heart className="w-4 h-4 text-primary mr-3" />
                  Social Impact
                </a>
              </li>
              <li>
                <a href="#" className="text-muted-foreground hover:text-accent transition-colors hover:pl-2 duration-300 flex items-center">
                  <Pen className="w-4 h-4 text-primary mr-3" />
                  Creative Writing
                </a>
              </li>
              <li>
                <a href="#" className="text-muted-foreground hover:text-accent transition-colors hover:pl-2 duration-300 flex items-center">
                  <Laptop className="w-4 h-4 text-primary mr-3" />
                  Technology
                </a>
              </li>
              <li>
                <a href="#" className="text-muted-foreground hover:text-accent transition-colors hover:pl-2 duration-300 flex items-center">
                  <Leaf className="w-4 h-4 text-primary mr-3" />
                  Environment
                </a>
              </li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h3 className="text-xl font-semibold text-accent mb-6 relative">
              Support
              <div className="absolute -bottom-2 left-0 w-12 h-1 bg-primary rounded-full"></div>
            </h3>
            <ul className="space-y-3">
              <li>
                <a href="#" className="text-muted-foreground hover:text-accent transition-colors hover:pl-2 duration-300 flex items-center">
                  <HelpCircle className="w-4 h-4 text-primary mr-3" />
                  Help Center
                </a>
              </li>
              <li>
                <a href="#" className="text-muted-foreground hover:text-accent transition-colors hover:pl-2 duration-300 flex items-center">
                  <Shield className="w-4 h-4 text-primary mr-3" />
                  Privacy Policy
                </a>
              </li>
              <li>
                <a href="#" className="text-muted-foreground hover:text-accent transition-colors hover:pl-2 duration-300 flex items-center">
                  <FileText className="w-4 h-4 text-primary mr-3" />
                  Terms of Service
                </a>
              </li>
              <li>
                <a href="#" className="text-muted-foreground hover:text-accent transition-colors hover:pl-2 duration-300 flex items-center">
                  <Mail className="w-4 h-4 text-primary mr-3" />
                  Contact Us
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-white/10 pt-8 text-center">
          <p className="text-muted-foreground/80 text-sm">
            © 2024 Young Blood. All rights reserved. Built with ❤️ for the next generation of storytellers.
          </p>
        </div>
      </div>
    </footer>
  );
}
