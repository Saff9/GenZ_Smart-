import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { 
  Bold, 
  Italic, 
  Underline, 
  List, 
  ListOrdered, 
  Link, 
  Image, 
  Quote,
  Code,
  Heading1,
  Heading2
} from "lucide-react";

interface RichTextEditorProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
}

export default function RichTextEditor({ value, onChange, placeholder = "Start writing..." }: RichTextEditorProps) {
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const [selectionStart, setSelectionStart] = useState(0);
  const [selectionEnd, setSelectionEnd] = useState(0);

  useEffect(() => {
    const textarea = textareaRef.current;
    if (textarea) {
      const handleSelect = () => {
        setSelectionStart(textarea.selectionStart);
        setSelectionEnd(textarea.selectionEnd);
      };
      
      textarea.addEventListener('select', handleSelect);
      textarea.addEventListener('click', handleSelect);
      textarea.addEventListener('keyup', handleSelect);
      
      return () => {
        textarea.removeEventListener('select', handleSelect);
        textarea.removeEventListener('click', handleSelect);
        textarea.removeEventListener('keyup', handleSelect);
      };
    }
  }, []);

  const insertText = (before: string, after: string = '') => {
    const textarea = textareaRef.current;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selectedText = value.substring(start, end);
    
    const newText = value.substring(0, start) + before + selectedText + after + value.substring(end);
    onChange(newText);
    
    // Restore cursor position
    setTimeout(() => {
      textarea.focus();
      textarea.setSelectionRange(start + before.length, end + before.length);
    }, 0);
  };

  const insertLineText = (prefix: string) => {
    const textarea = textareaRef.current;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const lines = value.split('\n');
    let currentLine = 0;
    let currentPos = 0;
    
    // Find which line the cursor is on
    for (let i = 0; i < lines.length; i++) {
      if (currentPos + lines[i].length >= start) {
        currentLine = i;
        break;
      }
      currentPos += lines[i].length + 1; // +1 for newline
    }
    
    lines[currentLine] = prefix + lines[currentLine];
    const newText = lines.join('\n');
    onChange(newText);
    
    setTimeout(() => {
      textarea.focus();
      textarea.setSelectionRange(start + prefix.length, start + prefix.length);
    }, 0);
  };

  const toolbarButtons = [
    { icon: Bold, action: () => insertText('**', '**'), label: 'Bold' },
    { icon: Italic, action: () => insertText('*', '*'), label: 'Italic' },
    { icon: Underline, action: () => insertText('<u>', '</u>'), label: 'Underline' },
    { icon: Heading1, action: () => insertLineText('# '), label: 'Heading 1' },
    { icon: Heading2, action: () => insertLineText('## '), label: 'Heading 2' },
    { icon: List, action: () => insertLineText('- '), label: 'Bullet List' },
    { icon: ListOrdered, action: () => insertLineText('1. '), label: 'Numbered List' },
    { icon: Quote, action: () => insertLineText('> '), label: 'Quote' },
    { icon: Code, action: () => insertText('`', '`'), label: 'Code' },
    { icon: Link, action: () => insertText('[', '](url)'), label: 'Link' },
    { icon: Image, action: () => insertText('![alt text](', ')'), label: 'Image' },
  ];

  return (
    <div className="border border-white/10 rounded-xl overflow-hidden">
      {/* Toolbar */}
      <div className="bg-white/5 px-4 py-3 border-b border-white/10 flex items-center space-x-2 flex-wrap">
        {toolbarButtons.map(({ icon: Icon, action, label }, index) => (
          <Button
            key={index}
            type="button"
            variant="ghost"
            size="sm"
            onClick={action}
            className="h-8 w-8 p-0 text-muted-foreground hover:text-white hover:bg-white/10 rounded transition-colors"
            title={label}
          >
            <Icon className="h-4 w-4" />
          </Button>
        ))}
      </div>
      
      {/* Text Area */}
      <Textarea
        ref={textareaRef}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="min-h-[400px] bg-transparent border-0 text-white placeholder-muted-foreground focus:ring-0 focus:border-0 resize-none rounded-none"
        style={{ outline: 'none', boxShadow: 'none' }}
      />
      
      {/* Help Text */}
      <div className="bg-white/5 px-4 py-2 border-t border-white/10 text-xs text-muted-foreground">
        <p>
          <strong>Tip:</strong> Use **bold**, *italic*, # headings, - lists, `code`, [links](url), and ![images](url) for formatting
        </p>
      </div>
    </div>
  );
}
