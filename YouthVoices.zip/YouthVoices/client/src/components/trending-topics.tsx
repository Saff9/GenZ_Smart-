import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, Hash, Flame, Zap } from "lucide-react";

interface TrendingTopic {
  id: string;
  name: string;
  posts: number;
  trend: "up" | "hot" | "new";
  color: "primary" | "accent" | "secondary";
}

export default function TrendingTopics() {
  const trendingTopics: TrendingTopic[] = [
    { id: "1", name: "Youth Activism", posts: 127, trend: "hot", color: "primary" },
    { id: "2", name: "Climate Change", posts: 89, trend: "up", color: "accent" },
    { id: "3", name: "Mental Health", posts: 156, trend: "hot", color: "primary" },
    { id: "4", name: "Technology", posts: 73, trend: "new", color: "secondary" },
    { id: "5", name: "Creative Writing", posts: 94, trend: "up", color: "accent" },
    { id: "6", name: "Entrepreneurship", posts: 42, trend: "new", color: "secondary" },
    { id: "7", name: "Social Justice", posts: 118, trend: "hot", color: "primary" },
    { id: "8", name: "Education", posts: 67, trend: "up", color: "accent" },
  ];

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case "hot":
        return <Flame className="w-3 h-3" />;
      case "up":
        return <TrendingUp className="w-3 h-3" />;
      case "new":
        return <Zap className="w-3 h-3" />;
      default:
        return <Hash className="w-3 h-3" />;
    }
  };

  const getTrendColor = (trend: string) => {
    switch (trend) {
      case "hot":
        return "text-red-400";
      case "up":
        return "text-green-400";
      case "new":
        return "text-blue-400";
      default:
        return "text-muted-foreground";
    }
  };

  return (
    <Card className="bg-glass border-white/10 sticky top-4">
      <CardContent className="p-6">
        <div className="flex items-center space-x-2 mb-4">
          <div className="w-8 h-8 bg-gradient-to-br from-primary/20 to-accent/20 rounded-full flex items-center justify-center">
            <TrendingUp className="w-4 h-4 text-primary" />
          </div>
          <h3 className="text-lg font-semibold text-white">Trending Topics</h3>
        </div>

        <div className="space-y-3">
          {trendingTopics.map((topic, index) => (
            <div
              key={topic.id}
              className="flex items-center justify-between p-3 rounded-lg bg-white/5 hover:bg-white/10 transition-colors cursor-pointer group"
            >
              <div className="flex items-center space-x-3">
                <div className="flex items-center space-x-1">
                  <span className="text-sm font-medium text-muted-foreground">
                    {index + 1}
                  </span>
                  <div className={getTrendColor(topic.trend)}>
                    {getTrendIcon(topic.trend)}
                  </div>
                </div>
                <div>
                  <h4 className="font-medium text-white group-hover:text-accent transition-colors">
                    {topic.name}
                  </h4>
                  <p className="text-xs text-muted-foreground">
                    {topic.posts} posts
                  </p>
                </div>
              </div>
              <Badge
                variant="secondary"
                className={`bg-${topic.color}/20 text-${topic.color} border-${topic.color}/20`}
              >
                <Hash className="w-3 h-3 mr-1" />
                {topic.trend}
              </Badge>
            </div>
          ))}
        </div>

        <div className="mt-6 pt-4 border-t border-white/10">
          <p className="text-xs text-muted-foreground text-center">
            Topics are updated every hour based on activity
          </p>
        </div>
      </CardContent>
    </Card>
  );
}