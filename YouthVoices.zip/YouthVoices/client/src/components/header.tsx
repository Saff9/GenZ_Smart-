import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Feather, Home, Newspaper, PenTool, Users, Menu, LogOut, User } from "lucide-react";

export default function Header() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navigation = [
    { name: 'Home', href: '/', icon: Home },
    { name: 'Articles', href: '#articles', icon: Newspaper },
    { name: 'Write', href: '/write', icon: PenTool },
    { name: 'Community', href: '#community', icon: Users },
  ];

  const isActive = (href: string) => {
    if (href === '/') return location === '/';
    if (href.startsWith('#')) return false; // Handle anchor links differently
    return location.startsWith(href);
  };

  return (
    <header className="sticky top-0 z-50 bg-dark-bg/90 backdrop-blur-md border-b border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center space-x-3">
            <Feather className="w-8 h-8 text-primary" />
            <div>
              <h1 className="text-2xl font-montserrat font-bold text-gradient">
                YOUNGBLOOD
              </h1>
              <p className="text-xs text-accent -mt-1 opacity-80">
                Amplifying Youth Voices
              </p>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            {navigation.map((item) => (
              <Link
                key={item.name}
                href={item.href}
                className={`text-light hover:text-accent transition-colors duration-300 font-medium flex items-center ${
                  isActive(item.href) ? 'text-accent' : ''
                }`}
              >
                <item.icon className="w-4 h-4 mr-2" />
                {item.name}
              </Link>
            ))}
          </nav>

          {/* Auth Buttons / User Menu */}
          <div className="flex items-center space-x-4">
            {isLoading ? (
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-muted rounded-full animate-pulse"></div>
              </div>
            ) : isAuthenticated && user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                    <Avatar className="h-8 w-8 border-2 border-primary">
                      <AvatarImage src={user.profileImageUrl || undefined} alt={user.email} />
                      <AvatarFallback>
                        {user.firstName?.[0] || user.email[0].toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56" align="end" forceMount>
                  <DropdownMenuItem className="flex-col items-start">
                    <div className="text-sm font-medium text-white">
                      {user.firstName && user.lastName
                        ? `${user.firstName} ${user.lastName}`
                        : user.email}
                    </div>
                    <div className="text-xs text-muted-foreground">{user.email}</div>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href={`/profile/${user.id}`} className="flex items-center">
                      <User className="mr-2 h-4 w-4" />
                      <span>Profile</span>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/write" className="flex items-center">
                      <PenTool className="mr-2 h-4 w-4" />
                      <span>Write Article</span>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <a href="/api/logout" className="flex items-center">
                      <LogOut className="mr-2 h-4 w-4" />
                      <span>Log out</span>
                    </a>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <div className="flex items-center space-x-4">
                <Button
                  variant="outline"
                  className="px-4 py-2 text-accent border-accent rounded-full hover:bg-accent/10 transition-all duration-300"
                  onClick={() => window.location.href = '/api/login'}
                >
                  Sign In
                </Button>
                <Button
                  className="px-4 py-2 bg-primary text-white rounded-full hover:bg-primary/90 transition-all duration-300 hover:transform hover:-translate-y-0.5"
                  onClick={() => window.location.href = '/api/login'}
                >
                  Get Started
                </Button>
              </div>
            )}

            {/* Mobile Menu Button */}
            <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="md:hidden">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-80">
                <div className="flex flex-col space-y-4 mt-8">
                  {navigation.map((item) => (
                    <Link
                      key={item.name}
                      href={item.href}
                      className={`text-light hover:text-accent transition-colors duration-300 font-medium flex items-center p-2 rounded-lg ${
                        isActive(item.href) ? 'text-accent bg-accent/10' : ''
                      }`}
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      <item.icon className="w-5 h-5 mr-3" />
                      {item.name}
                    </Link>
                  ))}
                  
                  {!isAuthenticated && (
                    <div className="flex flex-col space-y-2 pt-4 border-t border-white/10">
                      <Button
                        variant="outline"
                        className="justify-start text-accent border-accent hover:bg-accent/10"
                        onClick={() => window.location.href = '/api/login'}
                      >
                        Sign In
                      </Button>
                      <Button
                        className="justify-start bg-primary hover:bg-primary/90"
                        onClick={() => window.location.href = '/api/login'}
                      >
                        Get Started
                      </Button>
                    </div>
                  )}
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  );
}
