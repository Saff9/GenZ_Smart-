import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Heart, MessageCircle, Share2, Bookmark, Eye, Calendar, User } from "lucide-react";
import { useState } from "react";
import { formatDistanceToNow } from "date-fns";

interface Article {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  author: string;
  category: string;
  createdAt: Date;
  likes: number;
  image?: string;
  readTime?: number;
  views?: number;
  comments?: number;
}

interface ArticleCardProps {
  article: Article;
  variant?: "default" | "featured" | "compact";
  onLike?: (id: string) => void;
  onBookmark?: (id: string) => void;
  onShare?: (id: string) => void;
  className?: string;
}

export default function ArticleCard({ 
  article, 
  variant = "default", 
  onLike, 
  onBookmark, 
  onShare, 
  className = "" 
}: ArticleCardProps) {
  const [isLiked, setIsLiked] = useState(false);
  const [isBookmarked, setIsBookmarked] = useState(false);
  const [likeCount, setLikeCount] = useState(article.likes || 0);

  const handleLike = () => {
    setIsLiked(!isLiked);
    setLikeCount(prev => isLiked ? prev - 1 : prev + 1);
    onLike?.(article.id);
  };

  const handleBookmark = () => {
    setIsBookmarked(!isBookmarked);
    onBookmark?.(article.id);
  };

  const handleShare = () => {
    onShare?.(article.id);
  };

  if (variant === "featured") {
    return (
      <Card className={`group relative overflow-hidden bg-glass border-white/10 hover:border-primary/30 transition-all duration-300 hover:transform hover:-translate-y-2 ${className}`}>
        <div className="relative h-64 overflow-hidden">
          {article.image && (
            <img 
              src={article.image} 
              alt={article.title}
              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
            />
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent" />
          <div className="absolute top-4 left-4">
            <Badge className="bg-primary/90 text-white border-0">
              {article.category}
            </Badge>
          </div>
          <div className="absolute top-4 right-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleBookmark}
              className="bg-black/20 hover:bg-black/40 text-white"
            >
              <Bookmark className={`w-4 h-4 ${isBookmarked ? 'fill-current' : ''}`} />
            </Button>
          </div>
          <div className="absolute bottom-6 left-6 right-6">
            <h3 className="text-xl font-bold text-white mb-2 line-clamp-2">
              {article.title}
            </h3>
            <p className="text-gray-200 text-sm line-clamp-2">
              {article.excerpt}
            </p>
          </div>
        </div>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center text-white text-sm font-bold">
                {article.author[0]}
              </div>
              <div>
                <p className="text-sm font-medium text-white">{article.author}</p>
                <p className="text-xs text-muted-foreground">
                  {formatDistanceToNow(article.createdAt, { addSuffix: true })}
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                size="sm"
                onClick={handleLike}
                className="text-muted-foreground hover:text-primary"
              >
                <Heart className={`w-4 h-4 mr-1 ${isLiked ? 'fill-current text-primary' : ''}`} />
                <span>{likeCount}</span>
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleShare}
                className="text-muted-foreground hover:text-accent"
              >
                <Share2 className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (variant === "compact") {
    return (
      <Card className={`group bg-glass border-white/10 hover:border-primary/30 transition-all duration-300 ${className}`}>
        <CardContent className="p-4">
          <div className="flex space-x-4">
            {article.image && (
              <div className="w-20 h-20 flex-shrink-0 rounded-lg overflow-hidden">
                <img 
                  src={article.image} 
                  alt={article.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
              </div>
            )}
            <div className="flex-1 min-w-0">
              <div className="flex items-center space-x-2 mb-2">
                <Badge variant="secondary" className="bg-accent/20 text-accent border-accent/20">
                  {article.category}
                </Badge>
                {article.readTime && (
                  <span className="text-xs text-muted-foreground flex items-center">
                    <Calendar className="w-3 h-3 mr-1" />
                    {article.readTime} min read
                  </span>
                )}
              </div>
              <h3 className="font-semibold text-white mb-2 line-clamp-2 group-hover:text-accent transition-colors">
                {article.title}
              </h3>
              <p className="text-sm text-muted-foreground line-clamp-2 mb-3">
                {article.excerpt}
              </p>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <User className="w-3 h-3 text-muted-foreground" />
                  <span className="text-xs text-muted-foreground">{article.author}</span>
                </div>
                <div className="flex items-center space-x-3 text-xs text-muted-foreground">
                  <span className="flex items-center">
                    <Heart className="w-3 h-3 mr-1" />
                    {likeCount}
                  </span>
                  {article.views && (
                    <span className="flex items-center">
                      <Eye className="w-3 h-3 mr-1" />
                      {article.views}
                    </span>
                  )}
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={`group bg-glass border-white/10 hover:border-primary/30 transition-all duration-300 hover:transform hover:-translate-y-1 ${className}`}>
      {article.image && (
        <div className="relative h-48 overflow-hidden">
          <img 
            src={article.image} 
            alt={article.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleBookmark}
              className="bg-black/20 hover:bg-black/40 text-white"
            >
              <Bookmark className={`w-4 h-4 ${isBookmarked ? 'fill-current' : ''}`} />
            </Button>
          </div>
        </div>
      )}
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <Badge className="bg-gradient-to-r from-accent/20 to-primary/20 text-accent border-accent/20">
            {article.category}
          </Badge>
          {article.readTime && (
            <span className="text-xs text-muted-foreground flex items-center">
              <Calendar className="w-3 h-3 mr-1" />
              {article.readTime} min read
            </span>
          )}
        </div>
        
        <h3 className="text-xl font-semibold mb-3 text-white group-hover:text-accent transition-colors line-clamp-2">
          {article.title}
        </h3>
        
        <p className="text-muted-foreground mb-4 leading-relaxed line-clamp-3">
          {article.excerpt}
        </p>
        
        <div className="flex items-center justify-between pt-4 border-t border-white/10">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center text-white text-sm font-bold">
              {article.author[0]}
            </div>
            <div>
              <p className="text-sm font-medium text-white">{article.author}</p>
              <p className="text-xs text-muted-foreground">
                {formatDistanceToNow(article.createdAt, { addSuffix: true })}
              </p>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleLike}
              className="text-muted-foreground hover:text-primary transition-colors"
            >
              <Heart className={`w-4 h-4 mr-1 ${isLiked ? 'fill-current text-primary' : ''}`} />
              <span>{likeCount}</span>
            </Button>
            
            <Button
              variant="ghost"
              size="sm"
              className="text-muted-foreground hover:text-accent transition-colors"
            >
              <MessageCircle className="w-4 h-4 mr-1" />
              <span>{article.comments || 0}</span>
            </Button>
            
            <Button
              variant="ghost"
              size="sm"
              onClick={handleShare}
              className="text-muted-foreground hover:text-accent transition-colors"
            >
              <Share2 className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}