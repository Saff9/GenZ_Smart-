import { useState } from "react";
import { Button } from "@/components/ui/button";
import { PlusCircle, Edit3, X, Zap, MessageSquare, Heart } from "lucide-react";
import { Link } from "wouter";
import { useAuth } from "@/hooks/useAuth";

export default function FloatingActionButton() {
  const [isExpanded, setIsExpanded] = useState(false);
  const { isAuthenticated } = useAuth();

  if (!isAuthenticated) return null;

  const toggleExpanded = () => setIsExpanded(!isExpanded);

  return (
    <div className="fixed bottom-6 right-6 z-50">
      {/* Expanded Menu */}
      {isExpanded && (
        <div className="absolute bottom-16 right-0 space-y-3 mb-4">
          <div className="flex flex-col space-y-2 fade-in">
            <Link href="/write">
              <Button
                className="w-12 h-12 bg-primary hover:bg-primary/90 text-white rounded-full shadow-lg hover:shadow-xl transition-all duration-300 group relative"
                onClick={() => setIsExpanded(false)}
              >
                <Edit3 className="w-5 h-5 group-hover:scale-110 transition-transform" />
                <span className="absolute right-14 top-1/2 -translate-y-1/2 bg-dark-bg text-white px-3 py-1 rounded-md text-sm whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity">
                  Write Article
                </span>
              </Button>
            </Link>
            
            <Button
              className="w-12 h-12 bg-accent hover:bg-accent/90 text-dark-bg rounded-full shadow-lg hover:shadow-xl transition-all duration-300 group relative"
              onClick={() => setIsExpanded(false)}
            >
              <MessageSquare className="w-5 h-5 group-hover:scale-110 transition-transform" />
              <span className="absolute right-14 top-1/2 -translate-y-1/2 bg-dark-bg text-white px-3 py-1 rounded-md text-sm whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity">
                Feedback
              </span>
            </Button>
            
            <Button
              className="w-12 h-12 bg-secondary hover:bg-secondary/90 text-white rounded-full shadow-lg hover:shadow-xl transition-all duration-300 group relative"
              onClick={() => setIsExpanded(false)}
            >
              <Zap className="w-5 h-5 group-hover:scale-110 transition-transform" />
              <span className="absolute right-14 top-1/2 -translate-y-1/2 bg-dark-bg text-white px-3 py-1 rounded-md text-sm whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity">
                Quick Actions
              </span>
            </Button>
          </div>
        </div>
      )}

      {/* Main FAB */}
      <Button
        onClick={toggleExpanded}
        className={`w-16 h-16 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 neon-glow ${
          isExpanded 
            ? 'bg-red-500 hover:bg-red-600 rotate-45' 
            : 'bg-gradient-to-br from-primary to-accent hover:from-primary/90 hover:to-accent/90'
        }`}
      >
        {isExpanded ? (
          <X className="w-6 h-6 text-white" />
        ) : (
          <PlusCircle className="w-6 h-6 text-white" />
        )}
      </Button>

      {/* Ripple Effect */}
      <div className="absolute inset-0 rounded-full animate-ping bg-primary/20 -z-10"></div>
    </div>
  );
}