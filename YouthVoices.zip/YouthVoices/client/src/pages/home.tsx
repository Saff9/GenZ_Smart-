import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import Header from "@/components/header";
import Footer from "@/components/footer";
import ArticleCard from "@/components/article-card";
import SearchBar from "@/components/search-bar";
import TrendingTopics from "@/components/trending-topics";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import { PlusCircle, TrendingUp, BookOpen, Users, Sparkles, Award, Flame } from "lucide-react";
import type { Article } from "@shared/schema";

export default function Home() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState("");
  const [filters, setFilters] = useState<{ category?: string; sortBy?: string }>({});

  const { data: articles, isLoading: articlesLoading } = useQuery({
    queryKey: ["/api/articles", searchQuery, filters],
    retry: false,
  });

  const { data: userArticles, isLoading: userArticlesLoading } = useQuery({
    queryKey: ["/api/users", user?.id, "articles"],
    enabled: !!user?.id,
    retry: false,
  });

  const handleSearch = (query: string) => {
    setSearchQuery(query);
  };

  const handleFilterChange = (newFilters: { category?: string; sortBy?: string }) => {
    setFilters(newFilters);
  };

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-dark-gradient">
        <Header />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <Card key={i} className="bg-glass">
                <Skeleton className="h-48 w-full" />
                <CardContent className="p-6">
                  <Skeleton className="h-4 w-24 mb-4" />
                  <Skeleton className="h-6 w-full mb-2" />
                  <Skeleton className="h-4 w-full mb-4" />
                  <div className="flex items-center space-x-2">
                    <Skeleton className="h-8 w-8 rounded-full" />
                    <Skeleton className="h-4 w-24" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-dark-gradient">
      <Header />

      {/* Welcome Section */}
      <section className="py-12 bg-dark-card/30 particle-bg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8 fade-in">
            <h1 className="text-4xl font-montserrat font-bold text-gradient mb-4">
              Welcome back, {user?.firstName || 'Writer'}!
            </h1>
            <p className="text-xl text-muted-foreground">
              Ready to share your voice with the world?
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6 mb-12">
            <Card className="bg-glass border-white/10 hover:border-primary/30 transition-all duration-300 text-center p-6 glow-on-hover fade-in">
              <div className="w-12 h-12 bg-gradient-to-br from-primary/20 to-accent/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <PlusCircle className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-lg font-semibold text-white mb-2">Start Writing</h3>
              <p className="text-muted-foreground mb-4">Create your next masterpiece</p>
              <Link href="/write">
                <Button className="bg-primary hover:bg-primary/90 glow-on-hover">
                  Write Article
                </Button>
              </Link>
            </Card>

            <Card className="bg-glass border-white/10 hover:border-accent/30 transition-all duration-300 text-center p-6 glow-on-hover fade-in" style={{animationDelay: '0.1s'}}>
              <div className="w-12 h-12 bg-gradient-to-br from-accent/20 to-primary/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <BookOpen className="w-6 h-6 text-accent" />
              </div>
              <h3 className="text-lg font-semibold text-white mb-2">Your Articles</h3>
              <p className="text-muted-foreground mb-4">
                {userArticles?.length || 0} articles published
              </p>
              <Link href={`/profile/${user?.id}`}>
                <Button variant="outline" className="border-accent text-accent hover:bg-accent/10 glow-on-hover">
                  View Profile
                </Button>
              </Link>
            </Card>

            <Card className="bg-glass border-white/10 hover:border-secondary/30 transition-all duration-300 text-center p-6 glow-on-hover fade-in" style={{animationDelay: '0.2s'}}>
              <div className="w-12 h-12 bg-gradient-to-br from-secondary/20 to-accent/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="w-6 h-6 text-secondary" />
              </div>
              <h3 className="text-lg font-semibold text-white mb-2">Community</h3>
              <p className="text-muted-foreground mb-4">Connect with other writers</p>
              <Button variant="outline" className="border-secondary text-secondary hover:bg-secondary/10 glow-on-hover">
                Explore
              </Button>
            </Card>
          </div>

          {/* Search Bar */}
          <SearchBar onSearch={handleSearch} onFilterChange={handleFilterChange} />
        </div>
      </section>

      {/* Featured Article */}
      {articles && articles.length > 0 && (
        <section className="py-12 bg-dark-card/20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-8 fade-in">
              <h2 className="text-3xl font-montserrat font-bold text-accent mb-4">
                Featured Story
              </h2>
              <div className="w-24 h-1 bg-gradient-to-r from-primary to-accent mx-auto rounded-full mb-6"></div>
            </div>
            <div className="max-w-4xl mx-auto">
              <ArticleCard 
                article={articles[0]} 
                variant="featured"
                className="fade-in"
              />
            </div>
          </div>
        </section>
      )}

      {/* Latest Articles with Sidebar */}
      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-3xl font-montserrat font-bold text-accent">
              {searchQuery || filters.category ? 'Search Results' : 'Latest Articles'}
            </h2>
            <div className="flex items-center space-x-4">
              <div className="flex items-center text-muted-foreground">
                <TrendingUp className="w-5 h-5 mr-2" />
                <span>Trending Now</span>
              </div>
              <div className="flex items-center text-muted-foreground">
                <Flame className="w-5 h-5 mr-2" />
                <span>Hot</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-3">
              {articlesLoading ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {[...Array(6)].map((_, i) => (
                    <Card key={i} className="bg-glass animate-pulse">
                      <Skeleton className="h-48 w-full" />
                      <CardContent className="p-6">
                        <Skeleton className="h-4 w-24 mb-4" />
                        <Skeleton className="h-6 w-full mb-2" />
                        <Skeleton className="h-4 w-full mb-4" />
                        <div className="flex items-center space-x-2">
                          <Skeleton className="h-8 w-8 rounded-full" />
                          <Skeleton className="h-4 w-24" />
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : articles?.length === 0 ? (
                <Card className="bg-glass border-white/10 text-center p-12 fade-in">
                  <BookOpen className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-white mb-2">
                    {searchQuery || filters.category ? 'No articles found' : 'No articles yet'}
                  </h3>
                  <p className="text-muted-foreground mb-6">
                    {searchQuery || filters.category 
                      ? 'Try adjusting your search or filters to find more articles.' 
                      : 'Be the first to share your story with the community!'}
                  </p>
                  <Link href="/write">
                    <Button className="bg-primary hover:bg-primary/90 glow-on-hover">
                      Write the First Article
                    </Button>
                  </Link>
                </Card>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {articles?.slice(1).map((article: Article, index: number) => (
                    <ArticleCard 
                      key={article.id} 
                      article={article} 
                      className="fade-in"
                      style={{animationDelay: `${index * 0.1}s`}}
                    />
                  ))}
                </div>
              )}
            </div>

            {/* Sidebar */}
            <div className="lg:col-span-1">
              <TrendingTopics />
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
