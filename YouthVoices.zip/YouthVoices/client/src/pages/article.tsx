import { useEffect, useState } from "react";
import { useParams } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import Header from "@/components/header";
import Footer from "@/components/footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Heart, MessageCircle, Share2, Calendar, User, Loader2 } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import type { Article, Comment, User as UserType } from "@shared/schema";

export default function ArticlePage() {
  const { id } = useParams<{ id: string }>();
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [commentText, setCommentText] = useState("");

  const { data: article, isLoading: articleLoading } = useQuery({
    queryKey: ["/api/articles", id],
    retry: false,
  });

  const { data: comments, isLoading: commentsLoading } = useQuery({
    queryKey: ["/api/articles", id, "comments"],
    retry: false,
  });

  const { data: likesData, isLoading: likesLoading } = useQuery({
    queryKey: ["/api/articles", id, "likes"],
    retry: false,
  });

  const createCommentMutation = useMutation({
    mutationFn: async (content: string) => {
      return await apiRequest('POST', `/api/articles/${id}/comments`, { content });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/articles", id, "comments"] });
      setCommentText("");
      toast({
        title: "Success!",
        description: "Your comment has been posted.",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to post comment. Please try again.",
        variant: "destructive",
      });
    },
  });

  const likeMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest('POST', `/api/articles/${id}/likes`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/articles", id, "likes"] });
      toast({
        title: "Liked!",
        description: "Article added to your favorites.",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Already liked",
        description: "You've already liked this article.",
        variant: "destructive",
      });
    },
  });

  const handleCommentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim()) return;
    createCommentMutation.mutate(commentText);
  };

  const handleLike = () => {
    if (!isAuthenticated) {
      toast({
        title: "Sign in required",
        description: "Please sign in to like articles.",
        variant: "destructive",
      });
      return;
    }
    likeMutation.mutate();
  };

  if (articleLoading) {
    return (
      <div className="min-h-screen bg-dark-gradient">
        <Header />
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Card className="bg-glass border-white/10">
            <CardContent className="p-8">
              <Skeleton className="h-8 w-3/4 mb-4" />
              <div className="flex items-center space-x-4 mb-6">
                <Skeleton className="h-12 w-12 rounded-full" />
                <div>
                  <Skeleton className="h-4 w-32 mb-2" />
                  <Skeleton className="h-3 w-24" />
                </div>
              </div>
              <Skeleton className="h-64 w-full mb-6" />
              <Skeleton className="h-4 w-full mb-2" />
              <Skeleton className="h-4 w-full mb-2" />
              <Skeleton className="h-4 w-3/4" />
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (!article) {
    return (
      <div className="min-h-screen bg-dark-gradient">
        <Header />
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Card className="bg-glass border-white/10 text-center p-12">
            <h1 className="text-2xl font-bold text-white mb-4">Article Not Found</h1>
            <p className="text-muted-foreground">
              The article you're looking for doesn't exist or has been removed.
            </p>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-dark-gradient">
      <Header />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Card className="bg-glass border-white/10">
          <CardContent className="p-8">
            {/* Article Header */}
            <div className="mb-8">
              <Badge className="bg-accent/20 text-accent border-accent/30 mb-4">
                {article.category}
              </Badge>
              <h1 className="text-4xl font-montserrat font-bold text-white mb-6 leading-tight">
                {article.title}
              </h1>
              
              <div className="flex items-center space-x-4 mb-6">
                <Avatar className="w-12 h-12 border-2 border-primary">
                  <AvatarImage src={article.author.profileImageUrl || undefined} />
                  <AvatarFallback>
                    {article.author.firstName?.[0] || article.author.email[0].toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <p className="text-white font-medium">
                    {article.author.firstName && article.author.lastName
                      ? `${article.author.firstName} ${article.author.lastName}`
                      : article.author.email}
                  </p>
                  <div className="flex items-center text-muted-foreground text-sm">
                    <Calendar className="w-4 h-4 mr-1" />
                    {formatDistanceToNow(new Date(article.createdAt), { addSuffix: true })}
                  </div>
                </div>
              </div>

              {/* Article Actions */}
              <div className="flex items-center space-x-6 py-4 border-t border-b border-white/10">
                <Button
                  variant="ghost"
                  onClick={handleLike}
                  disabled={likeMutation.isPending}
                  className="text-muted-foreground hover:text-primary"
                >
                  {likeMutation.isPending ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Heart className="w-4 h-4 mr-2" />
                  )}
                  {likesData?.count || 0}
                </Button>
                
                <Button
                  variant="ghost"
                  className="text-muted-foreground hover:text-accent"
                  onClick={() => document.getElementById('comments')?.scrollIntoView({ behavior: 'smooth' })}
                >
                  <MessageCircle className="w-4 h-4 mr-2" />
                  {comments?.length || 0}
                </Button>
                
                <Button
                  variant="ghost"
                  className="text-muted-foreground hover:text-secondary"
                  onClick={() => {
                    navigator.share?.({
                      title: article.title,
                      text: article.excerpt,
                      url: window.location.href,
                    }) || navigator.clipboard.writeText(window.location.href);
                    toast({
                      title: "Link copied!",
                      description: "Article link has been copied to clipboard.",
                    });
                  }}
                >
                  <Share2 className="w-4 h-4 mr-2" />
                  Share
                </Button>
              </div>
            </div>

            {/* Featured Image */}
            {article.featuredImageUrl && (
              <div className="mb-8">
                <img
                  src={article.featuredImageUrl}
                  alt={article.title}
                  className="w-full h-96 object-cover rounded-xl"
                />
              </div>
            )}

            {/* Article Content */}
            <div className="prose prose-invert max-w-none mb-12">
              <div dangerouslySetInnerHTML={{ __html: article.content }} />
            </div>

            {/* Comments Section */}
            <div id="comments" className="border-t border-white/10 pt-8">
              <h3 className="text-2xl font-montserrat font-bold text-accent mb-6">
                Comments ({comments?.length || 0})
              </h3>

              {/* Add Comment Form */}
              {isAuthenticated ? (
                <Card className="bg-white/5 border-white/10 mb-8">
                  <CardContent className="p-6">
                    <form onSubmit={handleCommentSubmit}>
                      <div className="flex space-x-4">
                        <Avatar className="w-10 h-10 border-2 border-primary">
                          <AvatarImage src={user?.profileImageUrl || undefined} />
                          <AvatarFallback>
                            {user?.firstName?.[0] || user?.email[0].toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1 space-y-4">
                          <Textarea
                            value={commentText}
                            onChange={(e) => setCommentText(e.target.value)}
                            placeholder="Share your thoughts..."
                            className="bg-white/5 border-white/10 text-white placeholder-muted-foreground focus:border-accent resize-none"
                            rows={3}
                          />
                          <div className="flex justify-end">
                            <Button
                              type="submit"
                              disabled={!commentText.trim() || createCommentMutation.isPending}
                              className="bg-primary hover:bg-primary/90"
                            >
                              {createCommentMutation.isPending ? (
                                <>
                                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                  Posting...
                                </>
                              ) : (
                                "Post Comment"
                              )}
                            </Button>
                          </div>
                        </div>
                      </div>
                    </form>
                  </CardContent>
                </Card>
              ) : (
                <Card className="bg-primary/10 border-primary/30 mb-8">
                  <CardContent className="p-6 text-center">
                    <p className="text-accent mb-4">
                      Please sign in to leave a comment
                    </p>
                    <Button
                      onClick={() => window.location.href = '/api/login'}
                      className="bg-primary hover:bg-primary/90"
                    >
                      Sign In
                    </Button>
                  </CardContent>
                </Card>
              )}

              {/* Comments List */}
              <div className="space-y-6">
                {commentsLoading ? (
                  [...Array(3)].map((_, i) => (
                    <Card key={i} className="bg-white/5 border-white/10">
                      <CardContent className="p-6">
                        <div className="flex space-x-4">
                          <Skeleton className="h-10 w-10 rounded-full" />
                          <div className="flex-1">
                            <Skeleton className="h-4 w-32 mb-2" />
                            <Skeleton className="h-4 w-full mb-2" />
                            <Skeleton className="h-4 w-3/4" />
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                ) : comments?.length === 0 ? (
                  <div className="text-center py-8">
                    <MessageCircle className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                    <p className="text-muted-foreground">
                      No comments yet. Be the first to share your thoughts!
                    </p>
                  </div>
                ) : (
                  comments?.map((comment: Comment & { author: UserType }) => (
                    <Card key={comment.id} className="bg-white/5 border-white/10">
                      <CardContent className="p-6">
                        <div className="flex space-x-4">
                          <Avatar className="w-10 h-10 border-2 border-primary">
                            <AvatarImage src={comment.author.profileImageUrl || undefined} />
                            <AvatarFallback>
                              {comment.author.firstName?.[0] || comment.author.email[0].toUpperCase()}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1">
                            <div className="flex items-center space-x-2 mb-2">
                              <p className="font-medium text-white">
                                {comment.author.firstName && comment.author.lastName
                                  ? `${comment.author.firstName} ${comment.author.lastName}`
                                  : comment.author.email}
                              </p>
                              <span className="text-muted-foreground text-sm">
                                {formatDistanceToNow(new Date(comment.createdAt), { addSuffix: true })}
                              </span>
                            </div>
                            <p className="text-muted-foreground">{comment.content}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Footer />
    </div>
  );
}
