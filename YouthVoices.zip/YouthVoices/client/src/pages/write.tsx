import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { insertArticleSchema } from "@shared/schema";
import { z } from "zod";
import Header from "@/components/header";
import Footer from "@/components/footer";
import RichTextEditor from "@/components/rich-text-editor";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, Upload, FileText, Eye, Save, Sparkles, Palette, Hash } from "lucide-react";
import { useLocation } from "wouter";

const writeFormSchema = insertArticleSchema.extend({
  allowComments: z.boolean().default(true),
  saveDraft: z.boolean().default(false),
});

type WriteFormData = z.infer<typeof writeFormSchema>;

export default function Write() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewMode, setPreviewMode] = useState(false);

  const form = useForm<WriteFormData>({
    resolver: zodResolver(writeFormSchema),
    defaultValues: {
      title: "",
      content: "",
      excerpt: "",
      category: "",
      featuredImageUrl: "",
      published: true,
      allowComments: true,
      saveDraft: false,
    },
  });

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const createArticleMutation = useMutation({
    mutationFn: async (data: WriteFormData) => {
      const formData = new FormData();
      Object.entries(data).forEach(([key, value]) => {
        if (value !== undefined && value !== null) {
          formData.append(key, value.toString());
        }
      });
      
      if (selectedFile) {
        formData.append('featuredImage', selectedFile);
      }

      return await apiRequest('POST', '/api/articles', formData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/articles'] });
      queryClient.invalidateQueries({ queryKey: ['/api/users', user?.id, 'articles'] });
      toast({
        title: "Success!",
        description: "Your article has been published successfully.",
      });
      setLocation('/');
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to publish article. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedFile(file);
    }
  };

  const onSubmit = (data: WriteFormData) => {
    const finalData = {
      ...data,
      published: !data.saveDraft,
      excerpt: data.excerpt || data.content.substring(0, 200) + "...",
    };
    createArticleMutation.mutate(finalData);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-dark-gradient flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-dark-gradient">
      <Header />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Card className="bg-glass border-white/10">
          <CardHeader className="text-center">
            <CardTitle className="text-4xl font-montserrat font-bold text-accent mb-4">
              Share Your Story
            </CardTitle>
            <p className="text-xl text-muted-foreground">
              Every voice matters. What's your story?
            </p>
          </CardHeader>
          
          <CardContent className="p-8">
            {!isAuthenticated && (
              <Alert className="mb-6 bg-primary/10 border-primary/30">
                <AlertDescription className="text-accent">
                  Please sign in to start writing your article
                </AlertDescription>
              </Alert>
            )}

            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-accent">Article Title</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="Enter a compelling title for your article"
                          className="bg-white/5 border-white/10 text-white placeholder-muted-foreground focus:border-accent"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="category"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-accent">Category</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger className="bg-white/5 border-white/10 text-white focus:border-accent">
                            <SelectValue placeholder="Select a category" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="social-impact">Social Impact</SelectItem>
                          <SelectItem value="creative-writing">Creative Writing</SelectItem>
                          <SelectItem value="technology">Technology</SelectItem>
                          <SelectItem value="environment">Environment</SelectItem>
                          <SelectItem value="entrepreneurship">Entrepreneurship</SelectItem>
                          <SelectItem value="community">Community</SelectItem>
                          <SelectItem value="personal-story">Personal Story</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div>
                  <label className="block text-sm font-medium text-accent mb-2">
                    Featured Image
                  </label>
                  <div className="flex items-center space-x-4">
                    <label className="px-6 py-3 bg-accent/20 text-accent border border-accent/30 rounded-xl cursor-pointer hover:bg-accent/30 transition-all duration-300 font-medium flex items-center">
                      <Upload className="w-4 h-4 mr-2" />
                      Choose Image
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleFileChange}
                        className="hidden"
                      />
                    </label>
                    <span className="text-muted-foreground text-sm">
                      {selectedFile ? selectedFile.name : "No file chosen"}
                    </span>
                  </div>
                </div>

                <FormField
                  control={form.control}
                  name="excerpt"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-accent">Excerpt (Optional)</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="Brief description of your article"
                          className="bg-white/5 border-white/10 text-white placeholder-muted-foreground focus:border-accent"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="content"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-accent">Article Content</FormLabel>
                      <FormControl>
                        {previewMode ? (
                          <div className="min-h-[400px] p-4 bg-white/5 border border-white/10 rounded-xl">
                            <div className="prose prose-invert max-w-none">
                              <div dangerouslySetInnerHTML={{ __html: field.value }} />
                            </div>
                          </div>
                        ) : (
                          <RichTextEditor
                            value={field.value}
                            onChange={field.onChange}
                            placeholder="Tell your story..."
                          />
                        )}
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="flex items-center space-x-6">
                  <FormField
                    control={form.control}
                    name="saveDraft"
                    render={({ field }) => (
                      <FormItem className="flex items-center space-x-2">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                            className="border-white/10 bg-white/5"
                          />
                        </FormControl>
                        <FormLabel className="text-muted-foreground text-sm">
                          Save as draft
                        </FormLabel>
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="allowComments"
                    render={({ field }) => (
                      <FormItem className="flex items-center space-x-2">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                            className="border-white/10 bg-white/5"
                          />
                        </FormControl>
                        <FormLabel className="text-muted-foreground text-sm">
                          Allow comments
                        </FormLabel>
                      </FormItem>
                    )}
                  />
                </div>

                <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4 pt-6">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setPreviewMode(!previewMode)}
                    className="border-white/10 text-muted-foreground hover:bg-white/10"
                  >
                    <Eye className="w-4 h-4 mr-2" />
                    {previewMode ? "Edit" : "Preview"}
                  </Button>
                  
                  <Button
                    type="submit"
                    disabled={createArticleMutation.isPending}
                    className="bg-primary hover:bg-primary/90 text-white"
                  >
                    {createArticleMutation.isPending ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Publishing...
                      </>
                    ) : (
                      <>
                        <FileText className="w-4 h-4 mr-2" />
                        {form.watch('saveDraft') ? 'Save Draft' : 'Publish Article'}
                      </>
                    )}
                  </Button>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>

      <Footer />
    </div>
  );
}
