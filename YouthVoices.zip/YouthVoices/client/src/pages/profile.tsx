import { useEffect } from "react";
import { useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import Header from "@/components/header";
import Footer from "@/components/footer";
import ArticleCard from "@/components/article-card";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { User, Calendar, MapPin, Link as LinkIcon, Mail, PenTool, Heart, MessageCircle } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { Link } from "wouter";
import type { Article, User as UserType } from "@shared/schema";

export default function Profile() {
  const { id } = useParams<{ id: string }>();
  const { user: currentUser, isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();

  const { data: profileUser, isLoading: userLoading } = useQuery({
    queryKey: ["/api/auth/user"],
    enabled: id === currentUser?.id,
    retry: false,
  });

  const { data: userArticles, isLoading: articlesLoading } = useQuery({
    queryKey: ["/api/users", id, "articles"],
    retry: false,
  });

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const isOwnProfile = currentUser?.id === id;
  const displayUser = isOwnProfile ? profileUser : currentUser;

  if (userLoading || isLoading) {
    return (
      <div className="min-h-screen bg-dark-gradient">
        <Header />
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Card className="bg-glass border-white/10 mb-8">
            <CardContent className="p-8">
              <div className="flex flex-col md:flex-row items-center space-y-6 md:space-y-0 md:space-x-8">
                <Skeleton className="w-32 h-32 rounded-full" />
                <div className="flex-1 text-center md:text-left">
                  <Skeleton className="h-8 w-48 mb-4" />
                  <Skeleton className="h-4 w-32 mb-2" />
                  <Skeleton className="h-4 w-40" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (!displayUser) {
    return (
      <div className="min-h-screen bg-dark-gradient">
        <Header />
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Card className="bg-glass border-white/10 text-center p-12">
            <h1 className="text-2xl font-bold text-white mb-4">Profile Not Found</h1>
            <p className="text-muted-foreground">
              The profile you're looking for doesn't exist.
            </p>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-dark-gradient">
      <Header />
      
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Profile Header */}
        <Card className="bg-glass border-white/10 mb-8">
          <CardContent className="p-8">
            <div className="flex flex-col md:flex-row items-center space-y-6 md:space-y-0 md:space-x-8">
              <Avatar className="w-32 h-32 border-4 border-primary">
                <AvatarImage src={displayUser.profileImageUrl || undefined} />
                <AvatarFallback className="text-4xl">
                  {displayUser.firstName?.[0] || displayUser.email[0].toUpperCase()}
                </AvatarFallback>
              </Avatar>
              
              <div className="flex-1 text-center md:text-left">
                <h1 className="text-4xl font-montserrat font-bold text-white mb-2">
                  {displayUser.firstName && displayUser.lastName
                    ? `${displayUser.firstName} ${displayUser.lastName}`
                    : displayUser.email}
                </h1>
                
                <div className="flex flex-wrap items-center justify-center md:justify-start space-x-6 text-muted-foreground mb-4">
                  <div className="flex items-center">
                    <Mail className="w-4 h-4 mr-2" />
                    {displayUser.email}
                  </div>
                  <div className="flex items-center">
                    <Calendar className="w-4 h-4 mr-2" />
                    Joined {formatDistanceToNow(new Date(displayUser.createdAt), { addSuffix: true })}
                  </div>
                </div>

                {displayUser.bio && (
                  <p className="text-muted-foreground mb-6 max-w-2xl">
                    {displayUser.bio}
                  </p>
                )}

                <div className="flex flex-wrap items-center justify-center md:justify-start space-x-6 text-sm">
                  <div className="flex items-center text-accent">
                    <PenTool className="w-4 h-4 mr-2" />
                    {userArticles?.length || 0} Articles
                  </div>
                </div>
              </div>

              {isOwnProfile && (
                <div className="flex flex-col space-y-2">
                  <Button className="bg-primary hover:bg-primary/90">
                    Edit Profile
                  </Button>
                  <Link href="/write">
                    <Button variant="outline" className="border-accent text-accent hover:bg-accent/10">
                      Write Article
                    </Button>
                  </Link>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Articles Section */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-3xl font-montserrat font-bold text-accent">
              {isOwnProfile ? 'Your Articles' : 'Articles'}
            </h2>
            {isOwnProfile && (
              <Link href="/write">
                <Button className="bg-primary hover:bg-primary/90">
                  <PenTool className="w-4 h-4 mr-2" />
                  Write New Article
                </Button>
              </Link>
            )}
          </div>

          {articlesLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[...Array(6)].map((_, i) => (
                <Card key={i} className="bg-glass">
                  <Skeleton className="h-48 w-full" />
                  <CardContent className="p-6">
                    <Skeleton className="h-4 w-24 mb-4" />
                    <Skeleton className="h-6 w-full mb-2" />
                    <Skeleton className="h-4 w-full mb-4" />
                    <div className="flex items-center space-x-2">
                      <Skeleton className="h-8 w-8 rounded-full" />
                      <Skeleton className="h-4 w-24" />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : userArticles?.length === 0 ? (
            <Card className="bg-glass border-white/10 text-center p-12">
              <PenTool className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">
                {isOwnProfile ? 'No articles yet' : 'No articles published'}
              </h3>
              <p className="text-muted-foreground mb-6">
                {isOwnProfile 
                  ? 'Start sharing your thoughts and stories with the world!'
                  : 'This user hasn\'t published any articles yet.'
                }
              </p>
              {isOwnProfile && (
                <Link href="/write">
                  <Button className="bg-primary hover:bg-primary/90">
                    Write Your First Article
                  </Button>
                </Link>
              )}
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {userArticles?.map((article: Article) => (
                <ArticleCard key={article.id} article={article} />
              ))}
            </div>
          )}
        </div>
      </div>

      <Footer />
    </div>
  );
}
