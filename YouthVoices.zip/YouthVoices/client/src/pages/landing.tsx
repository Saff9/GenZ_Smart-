import Header from "@/components/header";
import Footer from "@/components/footer";
import NewsletterSignup from "@/components/newsletter-signup";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Feather, Mic, Users, Rocket, TrendingUp, Heart, MessageCircle, PenTool, Laptop, Leaf, Sparkles, BookOpen } from "lucide-react";

export default function Landing() {
  const featuredArticles = [
    {
      id: 1,
      title: "The Power of Youth Activism in the Digital Age",
      excerpt: "How young people are leveraging social media and technology to drive meaningful change in their communities and beyond.",
      category: "Social Impact",
      author: "Sarah Chen",
      date: "March 15, 2024",
      likes: 127,
      image: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=800&h=400&fit=crop"
    },
    {
      id: 2,
      title: "Finding Your Voice: A Guide to Authentic Storytelling",
      excerpt: "Every writer has a unique perspective. Learn how to embrace your authentic voice and share stories that matter.",
      category: "Creative Writing",
      author: "Marcus Johnson",
      date: "March 12, 2024",
      likes: 89,
      image: "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=800&h=400&fit=crop"
    },
    {
      id: 3,
      title: "Building Bridges: The Future of Youth Collaboration",
      excerpt: "Exploring how young people from different backgrounds are coming together to solve global challenges.",
      category: "Community",
      author: "Emma Rodriguez",
      date: "March 10, 2024",
      likes: 156,
      image: "https://images.unsplash.com/photo-1529070538774-1843cb3265df?w=800&h=400&fit=crop"
    },
    {
      id: 4,
      title: "Digital Natives: Redefining Creative Expression",
      excerpt: "How Gen Z is using technology to create new forms of art, communication, and social connection.",
      category: "Technology",
      author: "Alex Kim",
      date: "March 8, 2024",
      likes: 203,
      image: "https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=800&h=400&fit=crop"
    },
    {
      id: 5,
      title: "Climate Action: The Youth Movement That's Changing the World",
      excerpt: "Young climate activists are leading the charge for environmental justice and sustainable futures.",
      category: "Environment",
      author: "Maya Patel",
      date: "March 5, 2024",
      likes: 178,
      image: "https://images.unsplash.com/photo-1581833971358-2c8b550f87b3?w=800&h=400&fit=crop"
    },
    {
      id: 6,
      title: "Young Entrepreneurs: Building Tomorrow's Solutions Today",
      excerpt: "Meet the young innovators who are creating businesses that solve real-world problems.",
      category: "Entrepreneurship",
      author: "David Thompson",
      date: "March 3, 2024",
      likes: 134,
      image: "https://images.unsplash.com/photo-1553484771-371a605b060b?w=800&h=400&fit=crop"
    }
  ];

  return (
    <div className="min-h-screen bg-dark-gradient">
      <Header />
      
      {/* Hero Section */}
      <section className="relative py-20 lg:py-32 overflow-hidden particle-bg">
        <div className="absolute inset-0 z-0">
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-full h-full">
            <div className="w-96 h-96 bg-gradient-to-r from-primary/20 to-accent/20 rounded-full blur-3xl opacity-30 animate-pulse"></div>
          </div>
          <div className="absolute top-1/4 right-1/4 w-72 h-72 bg-gradient-to-l from-accent/10 to-primary/10 rounded-full blur-2xl opacity-20 floating-animation"></div>
          <div className="absolute bottom-1/4 left-1/4 w-80 h-80 bg-gradient-to-r from-primary/15 to-accent/15 rounded-full blur-2xl opacity-25 floating-animation" style={{animationDelay: '2s'}}></div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center max-w-4xl mx-auto fade-in">
            <div className="mb-6">
              <span className="inline-block px-4 py-2 bg-gradient-to-r from-primary/20 to-accent/20 rounded-full text-accent font-medium text-sm border border-accent/20 mb-4">
                ✨ Amplifying Youth Voices Since 2024
              </span>
            </div>
            <h1 className="text-5xl lg:text-7xl font-montserrat font-bold mb-6 text-gradient leading-tight">
              Your Voice,<br/>Your Story,<br/>Your Impact
            </h1>
            <p className="text-xl lg:text-2xl text-light/90 mb-8 leading-relaxed slide-up">
              Join a community of young writers, thinkers, and creators who are shaping the future through powerful storytelling and authentic voices.
            </p>
            
            {/* Stats */}
            <div className="grid grid-cols-3 gap-8 mb-12 max-w-md mx-auto">
              <div className="text-center">
                <div className="text-3xl font-bold text-primary mb-1">1000+</div>
                <div className="text-sm text-muted-foreground">Stories</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-accent mb-1">500+</div>
                <div className="text-sm text-muted-foreground">Writers</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-primary mb-1">50+</div>
                <div className="text-sm text-muted-foreground">Countries</div>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-6">
              <div className="rainbow-border">
                <Button 
                  size="lg" 
                  className="px-8 py-4 bg-dark-bg hover:bg-dark-bg/90 text-white rounded-xl font-semibold text-lg interactive-card relative overflow-hidden group"
                  onClick={() => window.location.href = '/api/login'}
                >
                  <span className="relative z-10 flex items-center">
                    <Feather className="w-5 h-5 mr-2" />
                    Start Writing Today
                  </span>
                  <div className="absolute inset-0 bg-gradient-to-r from-primary to-accent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </Button>
              </div>
              <Button 
                variant="outline" 
                size="lg"
                className="px-8 py-4 border-accent text-accent rounded-xl font-semibold text-lg hover:bg-accent/10 transition-all duration-300 hover:border-accent/50 glass-morphism"
                onClick={() => document.getElementById('featured-articles')?.scrollIntoView({ behavior: 'smooth' })}
              >
                <BookOpen className="w-5 h-5 mr-2" />
                Explore Articles
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Articles Section */}
      <section id="featured-articles" className="py-20 bg-dark-card/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16 fade-in">
            <h2 className="text-4xl lg:text-5xl font-montserrat font-bold text-accent mb-4">
              Featured Stories
            </h2>
            <div className="w-24 h-1 bg-gradient-to-r from-primary to-accent mx-auto rounded-full mb-6"></div>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Discover powerful narratives from young voices around the world
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredArticles.map((article, index) => (
              <Card 
                key={article.id} 
                className="bg-glass border-white/10 hover:border-primary/30 transition-all duration-300 hover:transform hover:-translate-y-2 group overflow-hidden fade-in"
                style={{animationDelay: `${index * 0.1}s`}}
              >
                <div className="relative overflow-hidden">
                  <img 
                    src={article.image} 
                    alt={article.title}
                    className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <div className="bg-primary/90 text-white px-3 py-1 rounded-full text-sm font-medium">
                      New
                    </div>
                  </div>
                </div>
                <CardContent className="p-6">
                  <div className="flex items-center space-x-2 mb-4">
                    <span className="bg-gradient-to-r from-accent/20 to-primary/20 text-accent px-3 py-1 rounded-full text-sm font-medium border border-accent/20">
                      {article.category}
                    </span>
                  </div>
                  <h3 className="text-xl font-semibold mb-3 text-white group-hover:text-accent transition-colors line-clamp-2">
                    {article.title}
                  </h3>
                  <p className="text-muted-foreground mb-4 leading-relaxed line-clamp-3">
                    {article.excerpt}
                  </p>
                  <div className="flex items-center justify-between pt-4 border-t border-white/10">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center text-white text-sm font-bold">
                        {article.author[0]}
                      </div>
                      <div>
                        <p className="text-sm font-medium text-white">{article.author}</p>
                        <p className="text-xs text-muted-foreground">{article.date}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3 text-muted-foreground text-sm">
                      <div className="flex items-center hover:text-primary transition-colors cursor-pointer">
                        <Heart className="w-4 h-4 mr-1" />
                        <span>{article.likes}</span>
                      </div>
                      <div className="flex items-center hover:text-accent transition-colors cursor-pointer">
                        <MessageCircle className="w-4 h-4 mr-1" />
                        <span>{Math.floor(Math.random() * 20) + 5}</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="text-center mt-12">
            <Button 
              variant="outline"
              className="px-8 py-3 bg-gradient-to-r from-accent/20 to-primary/20 text-accent border-accent/30 rounded-full font-semibold hover:bg-accent/30 transition-all duration-300 hover:scale-105 glow-on-hover"
              onClick={() => window.location.href = '/api/login'}
            >
              Load More Stories
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-dark-card/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-montserrat font-bold text-accent mb-4">
              Why Choose Young Blood?
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              We're more than just a platform - we're a community dedicated to amplifying youth voices
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                icon: Mic,
                title: "Authentic Voices",
                description: "Share your unique perspective and connect with readers who value authenticity"
              },
              {
                icon: Users,
                title: "Supportive Community",
                description: "Join a network of young writers who support and inspire each other"
              },
              {
                icon: Rocket,
                title: "Easy Publishing",
                description: "Intuitive tools make it simple to write, format, and publish your stories"
              },
              {
                icon: TrendingUp,
                title: "Reach & Impact",
                description: "Connect with readers worldwide and make a meaningful impact through your writing"
              }
            ].map((feature, index) => (
              <Card key={index} className="bg-glass border-white/10 hover:border-primary/30 transition-all duration-300 hover:transform hover:-translate-y-2 text-center p-8">
                <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-6 border border-primary/30">
                  <feature.icon className="w-8 h-8 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-4 text-accent">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.description}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* About Developer Section */}
      <section className="py-20 bg-gradient-to-br from-secondary to-dark relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/10 to-accent/10 opacity-30"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="flex flex-col lg:flex-row items-center space-y-12 lg:space-y-0 lg:space-x-16">
            <div className="flex-1 max-w-lg">
              <img 
                src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=600&h=600&fit=crop" 
                alt="Platform founder and developer" 
                className="w-full rounded-2xl shadow-2xl border-4 border-white/20 hover:scale-105 transition-transform duration-300"
              />
            </div>
            <div className="flex-1">
              <h2 className="text-4xl font-montserrat font-bold text-accent mb-4">
                Meet the Developer
              </h2>
              <h3 className="text-2xl text-primary mb-6">
                Building Platforms for Change
              </h3>
              <p className="text-lg text-light/90 mb-6 leading-relaxed">
                Hi, I'm a young developer passionate about creating spaces where youth voices can be heard and celebrated. Young Blood was born from the belief that every young person has a story worth telling.
              </p>
              <p className="text-lg text-light/90 mb-6 leading-relaxed">
                Through technology and community, we're building a platform that empowers the next generation of writers, thinkers, and change-makers.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Newsletter Signup */}
      <section className="py-20 bg-dark-card/50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12 fade-in">
            <h2 className="text-3xl font-montserrat font-bold text-accent mb-4">
              Join Our Community
            </h2>
            <p className="text-xl text-muted-foreground">
              Be part of the movement that's amplifying youth voices worldwide
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8">
            <div className="space-y-6 fade-in">
              <div className="flex items-start space-x-4">
                <div className="w-8 h-8 bg-primary/20 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <span className="text-primary font-bold">1</span>
                </div>
                <div>
                  <h3 className="font-semibold text-white mb-2">Weekly Digest</h3>
                  <p className="text-muted-foreground">Get the best youth stories delivered to your inbox every week.</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <div className="w-8 h-8 bg-accent/20 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <span className="text-accent font-bold">2</span>
                </div>
                <div>
                  <h3 className="font-semibold text-white mb-2">Exclusive Content</h3>
                  <p className="text-muted-foreground">Access to writer interviews, behind-the-scenes content, and writing tips.</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <div className="w-8 h-8 bg-primary/20 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <span className="text-primary font-bold">3</span>
                </div>
                <div>
                  <h3 className="font-semibold text-white mb-2">Community Events</h3>
                  <p className="text-muted-foreground">Be the first to know about virtual writing workshops and meetups.</p>
                </div>
              </div>
            </div>
            
            <div className="fade-in" style={{animationDelay: '0.2s'}}>
              <NewsletterSignup />
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
