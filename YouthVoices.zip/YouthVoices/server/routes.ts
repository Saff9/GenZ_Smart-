import type { Express, Request } from "express";
import express from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertArticleSchema, insertCommentSchema, insertLikeSchema } from "@shared/schema";
import { z } from "zod";
import multer from "multer";
import path from "path";
import fs from "fs";

// Configure multer for file uploads
const uploadDir = path.join(process.cwd(), "uploads");
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const upload = multer({
  storage: multer.diskStorage({
    destination: uploadDir,
    filename: (req, file, cb) => {
      const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
      cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
    }
  }),
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB limit
  },
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed'));
    }
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Serve uploaded files
  app.use('/uploads', express.static(uploadDir));

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Article routes
  app.get('/api/articles', async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 20;
      const offset = parseInt(req.query.offset as string) || 0;
      const articles = await storage.getArticles(limit, offset);
      res.json(articles);
    } catch (error) {
      console.error("Error fetching articles:", error);
      res.status(500).json({ message: "Failed to fetch articles" });
    }
  });

  app.get('/api/articles/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const article = await storage.getArticleWithAuthor(id);
      if (!article) {
        return res.status(404).json({ message: "Article not found" });
      }
      res.json(article);
    } catch (error) {
      console.error("Error fetching article:", error);
      res.status(500).json({ message: "Failed to fetch article" });
    }
  });

  app.post('/api/articles', isAuthenticated, upload.single('featuredImage'), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const articleData = {
        ...req.body,
        authorId: userId,
        featuredImageUrl: req.file ? `/uploads/${req.file.filename}` : null,
        published: req.body.published === 'true',
      };

      const validatedData = insertArticleSchema.parse(articleData);
      const article = await storage.createArticle(validatedData);
      res.status(201).json(article);
    } catch (error) {
      console.error("Error creating article:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid article data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create article" });
    }
  });

  app.put('/api/articles/:id', isAuthenticated, upload.single('featuredImage'), async (req: any, res) => {
    try {
      const id = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      
      const existingArticle = await storage.getArticleById(id);
      if (!existingArticle) {
        return res.status(404).json({ message: "Article not found" });
      }
      
      if (existingArticle.authorId !== userId) {
        return res.status(403).json({ message: "Not authorized to edit this article" });
      }

      const updateData = {
        ...req.body,
        featuredImageUrl: req.file ? `/uploads/${req.file.filename}` : existingArticle.featuredImageUrl,
        published: req.body.published === 'true',
      };

      const validatedData = insertArticleSchema.partial().parse(updateData);
      const article = await storage.updateArticle(id, validatedData);
      res.json(article);
    } catch (error) {
      console.error("Error updating article:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid article data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update article" });
    }
  });

  app.delete('/api/articles/:id', isAuthenticated, async (req: any, res) => {
    try {
      const id = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      
      const existingArticle = await storage.getArticleById(id);
      if (!existingArticle) {
        return res.status(404).json({ message: "Article not found" });
      }
      
      if (existingArticle.authorId !== userId) {
        return res.status(403).json({ message: "Not authorized to delete this article" });
      }

      await storage.deleteArticle(id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting article:", error);
      res.status(500).json({ message: "Failed to delete article" });
    }
  });

  // User articles
  app.get('/api/users/:id/articles', async (req, res) => {
    try {
      const userId = req.params.id;
      const articles = await storage.getArticlesByAuthor(userId);
      res.json(articles);
    } catch (error) {
      console.error("Error fetching user articles:", error);
      res.status(500).json({ message: "Failed to fetch user articles" });
    }
  });

  // Comment routes
  app.get('/api/articles/:id/comments', async (req, res) => {
    try {
      const articleId = parseInt(req.params.id);
      const comments = await storage.getCommentsByArticle(articleId);
      res.json(comments);
    } catch (error) {
      console.error("Error fetching comments:", error);
      res.status(500).json({ message: "Failed to fetch comments" });
    }
  });

  app.post('/api/articles/:id/comments', isAuthenticated, async (req: any, res) => {
    try {
      const articleId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      
      const commentData = {
        ...req.body,
        authorId: userId,
        articleId,
      };

      const validatedData = insertCommentSchema.parse(commentData);
      const comment = await storage.createComment(validatedData);
      res.status(201).json(comment);
    } catch (error) {
      console.error("Error creating comment:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid comment data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create comment" });
    }
  });

  // Like routes
  app.get('/api/articles/:id/likes', async (req, res) => {
    try {
      const articleId = parseInt(req.params.id);
      const count = await storage.getLikeCount(articleId);
      res.json({ count });
    } catch (error) {
      console.error("Error fetching like count:", error);
      res.status(500).json({ message: "Failed to fetch like count" });
    }
  });

  app.post('/api/articles/:id/likes', isAuthenticated, async (req: any, res) => {
    try {
      const articleId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      
      const existingLike = await storage.getUserLike(userId, articleId);
      if (existingLike) {
        return res.status(400).json({ message: "Already liked this article" });
      }

      const like = await storage.createLike({ userId, articleId });
      res.status(201).json(like);
    } catch (error) {
      console.error("Error creating like:", error);
      res.status(500).json({ message: "Failed to like article" });
    }
  });

  app.delete('/api/articles/:id/likes', isAuthenticated, async (req: any, res) => {
    try {
      const articleId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      
      await storage.deleteLike(userId, articleId);
      res.status(204).send();
    } catch (error) {
      console.error("Error removing like:", error);
      res.status(500).json({ message: "Failed to remove like" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
